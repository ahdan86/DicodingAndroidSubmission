package com.ahdan.githubuser2.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.ahdan.githubuser2.R

class MenuActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)
    }
}